/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package malatji.phineas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author maten
 */
public class MessageHandler {
    
      private static Connection con;
    private static Statement statem;
    private static ResultSet rsData;
    private static List<DesktopMessageHolder> desktopHandler = new ArrayList<>();
    
    static void connect() throws DataStorageException{
        String url = "jdbc:mysql://localhost/asd";
        String user = "root";
        String pass = "";
          try {
              Class.forName("com.mysql.jdbc.Driver");
              con = DriverManager.getConnection(url, user, pass);
          } catch (ClassNotFoundException ex) {
              throw new DataStorageException("Error 123: Failed to load driver class");
          } catch (SQLException ex) {
             throw new DataStorageException("Error 144: Failed connect to database");
          }
    }
    
    static void termate() throws DataStorageException{
       try{
        if(con != null){
            con.close();
        }
       }  catch (SQLException ex) {
             throw new DataStorageException("Error 1446: Failed to close connection");
          }
       
    }
    
    static List<DesktopMessageHolder> getMessageHistory(int desktopId) throws DataStorageException{
        String sql = "SELECT DISTINCT * FROM message WHERE desktopId="+desktopId + " ORDER BY dateSent ASC, timeSent ASC";
        
          try {
              statem = con.createStatement();
              rsData = statem.executeQuery(sql);
              
              while (rsData.next()) {                  
                  desktopHandler.add(new DesktopMessageHolder(rsData.getInt("desktopId"),
                          rsData.getString("message"), rsData.getString("dateSent"), rsData.getString("timeSent")));
              }
          } catch (SQLException ex) {
              throw new DataStorageException("Error 123448: Failed to fetch data"+ex.getMessage());
          }
          
          return desktopHandler;
        
    }
    
    static List<DesktopMessageHolder> getRecentMessages(int desktopId) throws DataStorageException{
        String sql = "SELECT DISTINCT * FROM message WHERE desktopId="+desktopId + " ORDER BY dateSent DESC, timeSent DESC";
        
          try {
              statem = con.createStatement();
              rsData = statem.executeQuery(sql);
              
              while (rsData.next()) {                  
                  desktopHandler.add(new DesktopMessageHolder(rsData.getInt("desktopId"),
                          rsData.getString("message"), rsData.getString("dateSent"), rsData.getString("timeSent")));
              }
          } catch (SQLException ex) {
              throw new DataStorageException("Error 123448: Failed to fetch data"+ex.getMessage());
          }
          
          return desktopHandler;
        
    }
    
    static void insertData(int desktopId, String message, String dateSent, String timeSent) throws DataStorageException{
        String sql = "INSERT INTO message VALUES("+desktopId+",'"+message+"','"+
                dateSent+"','"+timeSent+"')";
        
          try {
              statem = con.createStatement();
              
              if (statem.executeUpdate(sql) > 0) {
                  throw new DataStorageException("Message sent.");
              }
              else{
                  throw new DataStorageException("Failed to save to database. Please contact system administrator.");
              }
          } catch (SQLException ex) {
              throw new DataStorageException("Error 12344: Failed to save." + ex.getMessage());
          }
        
    }
//    List<DesktopMessageHolder> messageHolder = new ArrayList<>();
//    DesktopMessageHolder desktopMessageHolder;
//   public List<String> getRecentMessage(int desktopId){
//      return messageHolder.get(desktopId).getRecentMessages();
//   }
//   
//   public List<String> getHistoryMessage(int desktopId){
//      return messageHolder.get(desktopId).getHistoryMessages();
//   }
//    
//    void storeMessage(String message, int desktopId){
//        desktopMessageHolder = new DesktopMessageHolder(desktopId);
//        messageHolder.add(desktopMessageHolder);
//    }
}
