/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package malatji.phineas;

import java.sql.*;
import java.util.List;

/**
 *
 * @author maten
 */
public class DesktopMessageHolder {

  
    
// private List<String> recentMessages;
//    private List<String> historyMessages;
    private int desktopId;
    private String message, dateSent, timeSent;
    
//
//    public DesktopMessageHolder(int desktopId) {
//        setDesktopId(desktopId);
//    }
//
//    public void setRecentMessages(List<String> recentMessages) {
//        this.recentMessages = recentMessages;
//    }
//
//    public void setHistoryMessages(List<String> historyMessages) {
//        this.historyMessages = historyMessages;
//    }
//
//    public void setDesktopId(int desktopId) {
//        this.desktopId = desktopId;
//    }
//
//    public List<String> getRecentMessages() {
//        return recentMessages;
//    }
//
//    public List<String> getHistoryMessages() {
//        return historyMessages;
//    }
//
//    public int getDesktopId() {
//        return desktopId;
//    }
//    

    public DesktopMessageHolder(int desktopId, String message, String dateSent, String timeSent) {
        this.desktopId = desktopId;
        this.message = message;
        this.dateSent = dateSent;
        this.timeSent = timeSent;
    }

    public int getDesktopId() {
        return desktopId;
    }

    public void setDesktopId(int desktopId) {
        this.desktopId = desktopId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDateSent() {
        return dateSent;
    }

    public void setDateSent(String dateSent) {
        this.dateSent = dateSent;
    }

    public String getTimeSent() {
        return timeSent;
    }

    public void setTimeSent(String timeSent) {
        this.timeSent = timeSent;
    }

    @Override
    public String toString() {
        return message + "\t\t" + dateSent + "\t" + timeSent + "\n";
    }
    
    
    
    public static void connect() throws DataStorageException{
        MessageHandler.connect();
    }
    
    public static void terminate() throws DataStorageException{
        MessageHandler.termate();
    }
    
    public static List<DesktopMessageHolder> getMessageHistory(int desktopId) throws DataStorageException{
        return MessageHandler.getMessageHistory(desktopId);
    }
    
    public static List<DesktopMessageHolder> getRecentMessages(int desktopId) throws DataStorageException{
        return MessageHandler.getRecentMessages(desktopId);
    }
    public static void insertData(int desktopId, String message, String dateSent, String timeSent) throws DataStorageException{
        MessageHandler.insertData(desktopId, message, dateSent, timeSent);
    }
}
