/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package malatji.phineas;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author maten
 */
public class MessageHandlerTester {
static DesktopMessageHolder messageHolder;
private static List<DesktopMessageHolder> desktopHandler = new ArrayList<>();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
//        MessageHandler messageHandler = new MessageHandler();
        int option;
        String doContinue;
      
        
        do{
            connect();
            showMenu();
            option = sc.nextInt();
            if (option == 1) {
                storeMessage(sc);
            }
            else if (option == 2) {
                recentMessage(sc);
             }
            else if (option == 3) {
                historyMessages(sc);
            }
            else if (option == 4) {
                close();
            }
            else{
                 System.out.println("---------ERROR--------");
                System.out.println("Please enter option 1, 2, 3 or 4.");
            }
              System.out.print("Do you want to continue? - Enter [YES/NO] ");
              doContinue = sc.next();
              doContinue = doContinue.toUpperCase();
        } while (doContinue != "NO");
       
    }
//    
    static void showMenu(){
        System.out.println("--------Please select action below:--------");
        System.out.println("Option 1 - Store Messages\nOption 2 - View Recent Messages\nOption 3 - View History Messages\nOption 4 - Close Application");
        System.out.print("Please enter your option here: ");
    }
    
private static void connect(){
try{
        DesktopMessageHolder.connect();
         } catch (DataStorageException ex) {
            System.out.println("---------ERROR--------");
            System.out.println(ex.getMessage());
    }
}

    private static void storeMessage(Scanner sc){
          int desktopId = 0;
                   String message = "";
        String dateSent = "";
        String timeSent = "";
        try{
        System.out.println("-------Store Message--------");
                System.out.print("Enter desktop id: ");
                desktopId = sc.nextInt();
                
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
        Date myDate = new Date();
        
        dateSent = dateFormat.format(myDate);
        timeSent = timeFormat.format(myDate);
        
        System.out.print("Enter message: ");
                message = sc.next();
        
         messageHolder = new DesktopMessageHolder(desktopId, message, dateSent, timeSent);
                DesktopMessageHolder.insertData(messageHolder.getDesktopId()
                        , messageHolder.getMessage(), messageHolder.getDateSent()
                        , messageHolder.getTimeSent());
        } catch (DataStorageException ex) {
        System.out.println("---------ERROR--------");
            System.out.println(ex.getMessage());
    }
    }
    
    private static void recentMessage(Scanner sc){
        int desktopId;
        try{
          System.out.println("--------Recent Messages----------");
          System.out.print("Enter desktop id to view messages for: ");
                desktopId = sc.nextInt();
                  System.out.println(DesktopMessageHolder.getRecentMessages(desktopId).toString());  
        } catch (DataStorageException ex) {
            System.out.println("---------ERROR--------");
            System.out.println(ex.getMessage());
    }
        
         
    }
    
    private static void historyMessages(Scanner sc){
        
        int desktopId;  
        try{
        System.out.println("--------Message History----------");
          System.out.print("Enter desktop id to view messages for: ");
                desktopId = sc.nextInt();
                  System.out.println(DesktopMessageHolder.getMessageHistory(desktopId).toString());
        } catch (DataStorageException ex) {
       System.out.println("---------ERROR--------");
            System.out.println(ex.getMessage());
    }
    }
       private static void close(){
           try {
            DesktopMessageHolder.terminate();
               System.out.println("------Thanks for visiting, good bye.");
            System.exit(0);
        } catch (DataStorageException ex) {
               System.out.println("---------ERROR--------");
            System.out.println(ex.getMessage());
        }
       }
}
